package db;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.StringTokenizer;

import global.Parameter;

public class DBProcess {
	String dbURL;
	String username;
	String password;
	
	Connection connection = null;
	Statement stmt = null;
	ResultSet rs = null;
	
	public DBProcess(String dbURL, String username, String password) {
		this.dbURL = dbURL;
		this.username = username;
		this.password = password;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("NOT FOUND OJDBC DRIVER!!");
			e.printStackTrace();
		}
		try {
			// database connect
			connection = DriverManager.getConnection(dbURL,username,password);
			stmt = connection.createStatement();
			System.out.println("DATABASE CONNECTION OK...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void createTable(String tableName, String inputPath) {
		try {
			stmt.executeQuery("DROP TABLE "+tableName);
			stmt.executeQuery("CREATE TABLE "+tableName +"("
					+ "PRE VARCHAR(20),"
					+ "CUR VARCHAR(20),"
					+ "PROBABILITY NUMBER,"
					+ "PATH VARCHAR(50),"
					+ "LENGTH NUMBER)");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		double[][] matrix = makeMatrix(inputPath);
		insertMatrix(tableName, matrix);
//		showTable(tableName);
	}

	private double[][] makeMatrix(String inputPath){
		double[][] matrix = new double[Parameter.storeNum][Parameter.storeNum];
		try {
			FileInputStream stream;
			stream = new FileInputStream(inputPath);
			InputStreamReader reader = new InputStreamReader(stream);
			@SuppressWarnings("resource")
			BufferedReader buffer = new BufferedReader(reader);
			if(inputPath.contains("EMData")) {
				try {
					System.out.println("=== E M ===");
					buffer.readLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else
				System.out.println("=== O R I G I N A L ===");
			for(int i=0; i<Parameter.storeNum; i++) {
				String line = "";
				try {
					line = buffer.readLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				StringTokenizer st = new StringTokenizer(line,"\t");
				for(int j=0; j<Parameter.storeNum; j++) 
					matrix[i][j] = Double.parseDouble(st.nextToken());
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Row Sum = 1
		for(int i=0; i<matrix.length; i++) {
			double sum = 0;
			for(int j=0; j<matrix[i].length; j++) {
				sum += matrix[i][j];
			}
			for(int j=0; j<matrix[i].length; j++) {
				matrix[i][j] = matrix[i][j]/sum;
			}
		}
		return matrix;		
	}
			
	private void insertMatrix(String tableName, double[][] matrix) {
		try {
			for(int i=0; i<matrix.length; i++){
				for(int j=0; j<matrix[i].length; j++) {
					stmt.executeQuery("INSERT INTO "+tableName +"("
							+ "PRE, CUR, PROBABILITY, PATH, LENGTH )"
							+ "VALUES ("
							+ i+"," 
							+ j+"," 
							+ matrix[i][j]+"," 
							+ i+"||'-'||"+j+","
							+ "1)");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String recursiveQuery(String tableName, int pre, int cur, int length) {
		String result = "";
		try {
			rs = stmt.executeQuery("WITH ROUTES(PRE, CUR, PROBABILITY, PATH, LENGTH) AS ("
					+ 	"SELECT PRE, CUR, PROBABILITY, PATH, LENGTH "
					+ 	"FROM "+tableName+" "
					+ 	"UNION ALL "
					+ 		"SELECT ROUTES.PRE, "+tableName+".CUR, "
					+ 				"ROUTES.PROBABILITY*"+tableName+".PROBABILITY as PROBABILITY,"
					+ 				"ROUTES.PATH||'-'||"+tableName+".CUR as PATH,"
					+ 				"ROUTES.LENGTH+"+tableName+".LENGTH as LENGTH "
					+ 		"FROM ROUTES, "+tableName+" "
					+ 		"WHERE ROUTES.CUR = "+tableName+".PRE and ROUTES.LENGTH+"+tableName+".LENGTH<="+length
					+ ")"
					+ "SELECT * "
					+ "FROM ROUTES "
					+ "WHERE PRE='"+pre+"' and CUR='"+cur+"' and LENGTH<="+length+" and PROBABILITY != 0 "
					+ "ORDER BY PROBABILITY DESC"
					);
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnNumber = rsmd.getColumnCount();
			while(rs.next()) {
				for(int i=0; i<columnNumber; i++) {
					result += rs.getString(i+1)+"\t";
				}
				result += "\n";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public void showTable(String tableName) {
		try {
			rs = stmt.executeQuery("select * from "+ tableName);
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int columnNumber = rsmd.getColumnCount();
			while(rs.next()) {
				for(int i=0; i<columnNumber; i++) {
					System.out.print(rs.getString(i+1)+"\t");
				}
				System.out.println();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void closeProcess() {
		try {
			rs.close();
			stmt.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) { 
		String dbURL = "jdbc:oracle:thin:@localhost:1521:ORCL";
		String username = "scott";
		String password = "tiger";
		int start = 0;
		int end = 4;
		int length = 6;
		
		DBProcess dbp = new DBProcess(dbURL, username, password);
		dbp.createTable("ORIGINAL", "output\\result\\originalData_500000_10.txt");
		System.out.println(dbp.recursiveQuery("ORIGINAL", start, end, length));
		dbp.createTable("BEACON", "output\\result\\EMData_500000_10_0.25_0.35_0.65_2049.txt");
		System.out.println(dbp.recursiveQuery("BEACON", start, end, length));
		dbp.closeProcess();
	}
}
